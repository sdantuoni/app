<?php

require('conexion.php');
require('login.php');

//Initialize $_userInfo as a string to be converted to an object.
$_userInfo = "";



//Format the query to get the user's session ID matching their cookie.
$_pQuery = "SELECT * FROM `user` WHERE id = '" . $_SESSION["user_id"] . "'";

//Query the above formatted string.
$qResult = mysql_query($_pQuery);

//Put the fetched object into $qFetch and then feed into $_userInfo
while($qFetch = mysql_fetch_object($qResult))
{
	$_userInfo = $qFetch;
}

//Format $_userName with $_userInfo->name.
$_userName = $_userInfo->name;

//Format the query to retrieve the user's info. We don't need WHERE pass = '' because we've already figured that out in checkcreds.php
$szQuery = "SELECT * FROM `" . $_UsersTable . "` WHERE id = '" . $_userName . "'";

//Query the above formatted object, and die with mysql_error()
$qResult = mysql_query($szQuery) or die(mysql_error());

//Fetch the result object with mysql_fetch_object()
$qFetch = mysql_fetch_object($qResult);

//Format the $_skinImage string with the exact folder location of the skin image.
$_skinImage = 'display/SKINS/';
$_skinImage .= $qFetch->skin;
$_skinImage .= '.jpg';


/*
Format the page however and echo the user info!
*/

?>

