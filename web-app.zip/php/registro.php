<?php

$caracteres = "1234567890"; //posibles caracteres a usar
$numerodeletras=10; //numero de letras para generar el texto
$cadena = ""; //variable para almacenar la cadena generada
for($i=0;$i<$numerodeletras;$i++)
{
    $cadena .= substr($caracteres,rand(0,strlen($caracteres)),1); /*Extraemos 1 caracter de los caracteres 
entre el rango 0 a Numero de letras que tiene la cadena */
}


if(!empty($_POST)){
	if(isset($_POST["nombre"]) &&isset($_POST["apellido"]) &&isset($_POST["genero"]) &&isset($_POST["email"]) &&isset($_POST["password"]) &&isset($_POST["confirm_password"])){
		if($_POST["nombre"].$_POST["apellido"]!=""&& $_POST["genero"]!=""&&$_POST["email"]!=""&&$_POST["password"]!=""&&$_POST["password"]==$_POST["confirm_password"]){
			include "conexion.php";
			
			$found=false;
			$sql1= "select * from cuentas where nombre=\"$_POST[nombre]_$_POST[apellido]\" or email=\"$_POST[email]\"";
			$query = $con->query($sql1);
			while ($r=$query->fetch_array()) {
				$found=true;
				break;
			}
			if($found){
				print "<script>alert(\"Nombre en uso o email ya registrado.\");window.location='../login.php';</script>";
                break;
			}
			$sql = "insert into cuentas(nombre,sexo,email,pass,fecha,dinero,dinerobank,plevel,posx,posy,posz,dni) value (\"$_POST[nombre]_$_POST[apellido]\",\"$_POST[genero]\",\"$_POST[email]\",\"$_POST[password]\",NOW(),750,16000,1,1481.7340,-1743.4836,13.5469,".$cadena.")";
			$query = $con->query($sql);
            
            $sql2 = "insert into members(member_name,real_name,gender,email_address,passwd) value (\"$_POST[nombre]_$_POST[apellido]\",\"$_POST[nombre]_$_POST[apellido]\",\"$_POST[genero]\",\"$_POST[email]\",md5('$_POST[password]'))";
            $query2 = $con->query($sql2);
            
			if($query!=null){
				print "<script>alert(\"Registro exitoso. Proceda a ingresar\");window.location='../login.php';</script>";
			}
		}
	}
}



?>
